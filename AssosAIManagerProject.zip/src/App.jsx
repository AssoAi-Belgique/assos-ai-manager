import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function AssosAIManager() {
  const [message, setMessage] = useState("");
  const [aiResponse, setAIResponse] = useState("");
  const [grantRequest, setGrantRequest] = useState("");
  const [grantAIResponse, setGrantAIResponse] = useState("");
  const [stats, setStats] = useState("25 membres, 4 événements à venir, 2 campagnes en cours");
  const [accounting, setAccounting] = useState("Solde : 1.500€ | Dons : 8.000€");

  const handleGrantAI = () => {
    setGrantAIResponse("Demande générée via IA :\nObjet : Projet social\nMontant demandé : 12.000€\nRésumé : Notre ASBL souhaite renforcer son impact en zone urbaine défavorisée...");
  };

  const handleSendMessage = () => {
    alert("Message envoyé : " + message);
    setMessage("");
  };

  const handleAIResponse = () => {
    setAIResponse("Résultat IA : 5 subventions trouvées correspondant à votre domaine d'activité.");
  };

  return (
    <div className="p-6 grid gap-6">
      <h1 className="text-4xl font-bold text-center">Assos.AI Manager</h1>
      <Tabs defaultValue="dashboard">
        <TabsList className="flex flex-wrap justify-center">
          <TabsTrigger value="dashboard">📊 Tableau de bord</TabsTrigger>
          <TabsTrigger value="grants">💰 Subventions</TabsTrigger>
          <TabsTrigger value="hr">👥 RH</TabsTrigger>
          <TabsTrigger value="docs">📄 Documents</TabsTrigger>
          <TabsTrigger value="accounting">📚 Comptabilité</TabsTrigger>
          <TabsTrigger value="social">📱 Réseaux</TabsTrigger>
          <TabsTrigger value="alerts">🔔 Notifications</TabsTrigger>
          <TabsTrigger value="messaging">✉️ Messagerie</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <Card><CardContent className="p-4">
            <h2 className="text-2xl font-semibold mb-2">Statistiques globales</h2>
            <p>{stats}</p>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="grants">
          <Card><CardContent className="p-4 grid gap-4">
            <h2 className="text-xl font-semibold">Recherche intelligente de subventions</h2>
            <Button onClick={handleAIResponse}>Lancer la recherche (IA Gemini)</Button>
            <p className="bg-muted mt-2 p-3 rounded">{aiResponse}</p>
            <Textarea placeholder="Décrivez votre projet..." value={grantRequest} onChange={(e) => setGrantRequest(e.target.value)} />
            <Button onClick={handleGrantAI}>Générer une demande</Button>
            {grantAIResponse && <div className="bg-muted mt-2 p-3 rounded">{grantAIResponse}</div>}
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="hr">
          <Card><CardContent className="p-4 grid gap-4">
            <h2 className="text-xl font-semibold">Module RH</h2>
            <Input placeholder="Nom de l'employé" />
            <Input placeholder="Statut (CDI, bénévole...)" />
            <Button>Ajouter</Button>
            <Textarea placeholder="Absence, maladie, remarques..." />
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="docs">
          <Card><CardContent className="p-4 grid gap-4">
            <h2 className="text-xl font-semibold">Générateur de documents IA</h2>
            <p>Contrats, certificats, fins de contrat conformes au droit belge.</p>
            <Button>Créer un contrat (IA)</Button>
            <Input type="file" className="mt-2" />
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="accounting">
          <Card><CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Comptabilité simplifiée</h2>
            <p>{accounting}</p>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="social">
          <Card><CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Publications automatiques</h2>
            <Input placeholder="Texte à publier" />
            <Button className="mt-2">Publier sur les réseaux</Button>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="alerts">
          <Card><CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Notifications & Deadlines</h2>
            <p>Prochaine échéance : 15 août 2025 - Rapport trimestriel</p>
          </CardContent></Card>
        </TabsContent>

        <TabsContent value="messaging">
          <Card><CardContent className="p-4">
            <h2 className="text-xl font-semibold">Messagerie</h2>
            <Textarea placeholder="Message" value={message} onChange={(e) => setMessage(e.target.value)} />
            <Button className="mt-2" onClick={handleSendMessage}>Envoyer</Button>
          </CardContent></Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}